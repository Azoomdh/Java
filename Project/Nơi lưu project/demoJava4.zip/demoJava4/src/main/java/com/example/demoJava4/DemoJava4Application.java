package com.example.demoJava4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoJava4Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoJava4Application.class, args);
	}

}
