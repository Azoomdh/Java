package com.example.demoJava2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoJava2Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoJava2Application.class, args);
	}

}
