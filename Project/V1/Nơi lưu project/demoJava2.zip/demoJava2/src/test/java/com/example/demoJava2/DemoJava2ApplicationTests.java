package com.example.demoJava2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoJava2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
