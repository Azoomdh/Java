package com.example.demoJava3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoJava3Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoJava3Application.class, args);
	}

}
