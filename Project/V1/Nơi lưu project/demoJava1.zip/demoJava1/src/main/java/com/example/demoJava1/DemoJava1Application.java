package com.example.demoJava1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoJava1Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoJava1Application.class, args);
	}

}
